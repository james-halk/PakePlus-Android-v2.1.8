import { useState, useEffect, useCallback } from 'react';
import { advices } from '@/data/advices';

// 单条建议记录
interface AdviceRecord {
  index: number;      // 建议索引(0-499)
  read: boolean;      // 是否已读
}

// 每日记录
interface DailyRecord {
  date: string;           // 日期字符串 YYYY-MM-DD
  advices: AdviceRecord[]; // 3条建议
  currentIndex: number;   // 当前查看的索引
  createdAt: number;      // 创建时间戳
}

// 轮播状态
interface RotationState {
  remainingIndices: number[];  // 剩余未展示的建议索引
  lastShuffleTime: number;     // 上次洗牌时间
}

const HISTORY_KEY = 'advice_history';
const ROTATION_KEY = 'advice_rotation';
const ADVICES_PER_DAY = 3;
const TOTAL_ADVICES = 500;

// 获取日期字符串 YYYY-MM-DD
const getDateString = (date: Date = new Date()): string => {
  return date.toISOString().split('T')[0];
};

// 从localStorage获取数据
const getStorageData = <T,>(key: string, defaultValue: T): T => {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : defaultValue;
  } catch {
    return defaultValue;
  }
};

// 保存数据到localStorage
const setStorageData = <T,>(key: string, value: T): void => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error('Failed to save to localStorage:', e);
  }
};

// Fisher-Yates 洗牌算法
const shuffleArray = <T,>(array: T[]): T[] => {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
};

// 生成新的随机顺序
const generateNewRotation = (): RotationState => {
  const allIndices = Array.from({ length: TOTAL_ADVICES }, (_, i) => i);
  return {
    remainingIndices: shuffleArray(allIndices),
    lastShuffleTime: Date.now()
  };
};

// 获取指定日期的记录，如果不存在则创建
const getOrCreateDailyRecord = (
  dateStr: string,
  rotation: RotationState
): { record: DailyRecord; newRotation: RotationState } => {
  const history = getStorageData<Record<string, DailyRecord>>(HISTORY_KEY, {});
  
  // 如果已存在，直接返回
  if (history[dateStr]) {
    return { record: history[dateStr], newRotation: rotation };
  }
  
  // 需要创建新记录
  let currentRotation = { ...rotation };
  
  // 如果剩余不够3条，重新洗牌
  if (currentRotation.remainingIndices.length < ADVICES_PER_DAY) {
    currentRotation = generateNewRotation();
  }
  
  // 取出3条
  const selectedIndices = currentRotation.remainingIndices.slice(0, ADVICES_PER_DAY);
  const newRemaining = currentRotation.remainingIndices.slice(ADVICES_PER_DAY);
  
  const newRecord: DailyRecord = {
    date: dateStr,
    advices: selectedIndices.map(index => ({ index, read: false })),
    currentIndex: 0,
    createdAt: Date.now()
  };
  
  // 保存历史
  history[dateStr] = newRecord;
  setStorageData(HISTORY_KEY, history);
  
  // 更新轮播状态
  const newRotation: RotationState = {
    remainingIndices: newRemaining,
    lastShuffleTime: currentRotation.lastShuffleTime
  };
  setStorageData(ROTATION_KEY, newRotation);
  
  return { record: newRecord, newRotation };
};

// 更新记录
const updateDailyRecord = (dateStr: string, updates: Partial<DailyRecord>): void => {
  const history = getStorageData<Record<string, DailyRecord>>(HISTORY_KEY, {});
  if (history[dateStr]) {
    history[dateStr] = { ...history[dateStr], ...updates };
    setStorageData(HISTORY_KEY, history);
  }
};

// 标记建议为已读
const markAdviceAsRead = (dateStr: string, adviceIndex: number): void => {
  const history = getStorageData<Record<string, DailyRecord>>(HISTORY_KEY, {});
  if (history[dateStr]) {
    history[dateStr].advices[adviceIndex].read = true;
    setStorageData(HISTORY_KEY, history);
  }
};

// 获取所有有记录的日期
const getRecordedDates = (): string[] => {
  const history = getStorageData<Record<string, DailyRecord>>(HISTORY_KEY, {});
  return Object.keys(history).sort();
};

// 获取某月的记录日期
const getDatesInMonth = (year: number, month: number): string[] => {
  const history = getStorageData<Record<string, DailyRecord>>(HISTORY_KEY, {});
  const prefix = `${year}-${String(month + 1).padStart(2, '0')}`;
  return Object.keys(history)
    .filter(date => date.startsWith(prefix))
    .sort();
};

// 检查日期是否有记录
const hasRecord = (dateStr: string): boolean => {
  const history = getStorageData<Record<string, DailyRecord>>(HISTORY_KEY, {});
  return !!history[dateStr];
};

export const useAdviceCalendar = () => {
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [currentRecord, setCurrentRecord] = useState<DailyRecord | null>(null);
  const [rotation, setRotation] = useState<RotationState | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [viewedIndex, setViewedIndex] = useState(0);

  // 初始化
  useEffect(() => {
    const savedRotation = getStorageData<RotationState | null>(ROTATION_KEY, null);
    const initialRotation = savedRotation || generateNewRotation();
    setRotation(initialRotation);
    
    // 加载今天的记录
    const today = getDateString();
    const { record } = getOrCreateDailyRecord(today, initialRotation);
    setCurrentRecord(record);
    setViewedIndex(record.currentIndex);
    setIsLoading(false);
  }, []);

  // 切换到指定日期
  const switchToDate = useCallback((date: Date) => {
    if (!rotation) return;
    
    const dateStr = getDateString(date);
    const { record, newRotation } = getOrCreateDailyRecord(dateStr, rotation);
    
    setCurrentDate(date);
    setCurrentRecord(record);
    setViewedIndex(record.currentIndex);
    setRotation(newRotation);
  }, [rotation]);

  // 切换到上一条建议
  const goToPrevious = useCallback(() => {
    if (viewedIndex > 0) {
      const newIndex = viewedIndex - 1;
      setViewedIndex(newIndex);
      const dateStr = getDateString(currentDate);
      updateDailyRecord(dateStr, { currentIndex: newIndex });
      if (currentRecord) {
        setCurrentRecord({ ...currentRecord, currentIndex: newIndex });
      }
    }
  }, [viewedIndex, currentDate, currentRecord]);

  // 切换到下一条建议
  const goToNext = useCallback(() => {
    if (viewedIndex < ADVICES_PER_DAY - 1) {
      const newIndex = viewedIndex + 1;
      setViewedIndex(newIndex);
      const dateStr = getDateString(currentDate);
      updateDailyRecord(dateStr, { currentIndex: newIndex });
      markAdviceAsRead(dateStr, newIndex);
      if (currentRecord) {
        const newAdvices = [...currentRecord.advices];
        newAdvices[newIndex] = { ...newAdvices[newIndex], read: true };
        setCurrentRecord({ ...currentRecord, currentIndex: newIndex, advices: newAdvices });
      }
    }
  }, [viewedIndex, currentDate, currentRecord]);

  // 切换到指定建议
  const goToAdvice = useCallback((index: number) => {
    if (index >= 0 && index < ADVICES_PER_DAY) {
      setViewedIndex(index);
      const dateStr = getDateString(currentDate);
      updateDailyRecord(dateStr, { currentIndex: index });
      markAdviceAsRead(dateStr, index);
      if (currentRecord) {
        const newAdvices = [...currentRecord.advices];
        newAdvices[index] = { ...newAdvices[index], read: true };
        setCurrentRecord({ ...currentRecord, currentIndex: index, advices: newAdvices });
      }
    }
  }, [currentDate, currentRecord]);

  // 获取当前显示的建议
  const getCurrentAdvice = useCallback((): string => {
    if (!currentRecord || isLoading) return '';
    const adviceRecord = currentRecord.advices[viewedIndex];
    return advices[adviceRecord?.index] || '';
  }, [currentRecord, viewedIndex, isLoading]);

  // 获取当前建议的全局序号
  const getCurrentNumber = useCallback((): number => {
    if (!currentRecord || isLoading) return 0;
    return currentRecord.advices[viewedIndex]?.index + 1 || 0;
  }, [currentRecord, viewedIndex, isLoading]);

  // 获取今日三条建议的序号
  const getTodayAdviceNumbers = useCallback((): number[] => {
    if (!currentRecord) return [];
    return currentRecord.advices.map(a => a.index + 1);
  }, [currentRecord]);

  // 获取今日三条建议的阅读状态
  const getTodayReadStatus = useCallback((): boolean[] => {
    if (!currentRecord) return [];
    return currentRecord.advices.map(a => a.read);
  }, [currentRecord]);

  // 检查是否是今天
  const isToday = useCallback((): boolean => {
    return getDateString(currentDate) === getDateString(new Date());
  }, [currentDate]);

  // 获取当前日期字符串
  const currentDateString = getDateString(currentDate);

  // 是否可以前进/后退
  const canGoPrevious = viewedIndex > 0;
  const canGoNext = viewedIndex < ADVICES_PER_DAY - 1;

  return {
    // 当前建议
    currentAdvice: getCurrentAdvice(),
    currentNumber: getCurrentNumber(),
    currentIndex: viewedIndex,
    totalPerDay: ADVICES_PER_DAY,
    todayAdviceNumbers: getTodayAdviceNumbers(),
    todayReadStatus: getTodayReadStatus(),
    
    // 日期相关
    currentDate,
    currentDateString,
    isToday: isToday(),
    
    // 导航
    canGoPrevious,
    canGoNext,
    goToPrevious,
    goToNext,
    goToAdvice,
    switchToDate,
    
    // 日历数据
    getRecordedDates,
    getDatesInMonth,
    hasRecord,
    
    isLoading
  };
};

export default useAdviceCalendar;
