# 人生建议 - 每日随机展示应用

基于凯文·凯利《宝贵的人生建议》500条人生智慧的每日随机展示应用。

## 功能特点

- 📱 **每天随机展示3条建议** - 从500条人生建议中智能选取
- 🔄 **轮播不重复** - 在全部500条轮播完成之前不会重复
- 🎲 **每次顺序不同** - 每天的3条建议顺序随机
- 💾 **本地存储** - 记录阅读进度，刷新不丢失
- 🎨 **优雅界面** - 温暖的配色，舒适的阅读体验

## 使用方式

### 方式一：Web版本（推荐）

直接在浏览器中打开 `dist/index.html` 即可使用。

### 方式二：构建APK（Android应用）

#### 环境要求
- Node.js 18+
- Android Studio
- Android SDK
- Java JDK 11+

#### 构建步骤

1. 解压 `life-wisdom-app-minimal.tar.gz`

2. 安装依赖
```bash
cd life-wisdom-app-minimal
npm install
```

3. 同步Capacitor
```bash
npx cap sync android
```

4. 构建APK
```bash
cd android
./gradlew assembleDebug
```

构建完成后，APK文件位于：
`android/app/build/outputs/apk/debug/app-debug.apk`

#### 构建发布版APK

```bash
cd android
./gradlew assembleRelease
```

## 项目结构

```
├── android/              # Android原生项目
├── dist/                 # Web构建输出
├── src/
│   ├── data/
│   │   └── advices.ts   # 500条人生建议数据
│   ├── hooks/
│   │   └── useAdviceRotation.ts  # 轮播逻辑
│   └── App.tsx          # 主应用组件
├── capacitor.config.ts  # Capacitor配置
└── package.json
```

## 核心逻辑说明

### 轮播算法

1. **初始化**：将所有500条建议的索引随机打乱
2. **每日分配**：每天取前3条作为当日建议
3. **进度保存**：记录已展示的建议，避免重复
4. **循环重置**：当所有建议展示完毕后，重新随机排序

### 数据存储

使用 localStorage 存储：
- `daily_advices`: 当日建议索引和当前阅读位置
- `rotation_state`: 轮播状态（剩余索引、当前批次等）

## 技术栈

- React 18 + TypeScript
- Vite
- Tailwind CSS
- shadcn/ui
- Capacitor

## 数据来源

《宝贵的人生建议》 - 凯文·凯利 (Kevin Kelly)

中文版包含500条建议（英文原版460条 + 中文版独家40条）

## License

MIT
